package fr.audiopocket.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var urlInput: EditText
    private val pickVideo = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        root.addView(TextView(this).apply {
            text = "🎵 AudioPocket"
            textSize = 30f
            setTextColor(0xFF172554.toInt())
            gravity = Gravity.CENTER
        }, matchWidth())

        root.addView(TextView(this).apply {
            text = "Extrais l’audio de tes propres vidéos ou de fichiers que tu es autorisé à convertir."
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }, matchWidth())

        urlInput = EditText(this).apply {
            hint = "Coller un lien YouTube (facultatif)"
            singleLine = true
        }
        root.addView(urlInput, matchWidth())

        root.addView(Button(this).apply {
            text = "Ouvrir le lien dans YouTube"
            setOnClickListener { openYouTubeLink() }
        }, matchWidth())

        root.addView(Button(this).apply {
            text = "Choisir une vidéo sur mon téléphone"
            setOnClickListener { chooseVideo() }
        }, matchWidth())

        root.addView(TextView(this).apply {
            text = "Format de sortie : M4A (audio extrait sans réencodage quand la source le permet)."
            textSize = 13f
            setPadding(0, 16, 0, 8)
        }, matchWidth())

        status = TextView(this).apply {
            text = "Prêt. Les fichiers sont enregistrés dans Musique/AudioPocket."
            textSize = 14f
            setPadding(0, 12, 0, 0)
        }
        root.addView(status, matchWidth())
        setContentView(root)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    private fun openYouTubeLink() {
        val raw = urlInput.text.toString().trim()
        if (raw.isEmpty() || !(raw.startsWith("https://") || raw.startsWith("http://"))) {
            Toast.makeText(this, "Colle d’abord un lien valide.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(raw)))
        } catch (_: Exception) {
            status.text = "Impossible d’ouvrir ce lien sur cet appareil."
        }
    }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, pickVideo)
    }

    @Deprecated("Using startActivityForResult for compatibility with this starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideo && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            extractAudio(uri)
        }
    }

    private fun extractAudio(uri: Uri) {
        status.text = "Extraction audio en cours…"
        thread {
            try {
                val extractor = MediaExtractor()
                extractor.setDataSource(this, uri, null)
                var audioTrack = -1
                var audioFormat: MediaFormat? = null
                for (i in 0 until extractor.trackCount) {
                    val format = extractor.getTrackFormat(i)
                    val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("audio/")) {
                        audioTrack = i
                        audioFormat = format
                        break
                    }
                }
                if (audioTrack < 0 || audioFormat == null) {
                    extractor.release()
                    runOnUiThread { status.text = "Aucune piste audio trouvée dans cette vidéo." }
                    return@thread
                }

                val dir = File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "AudioPocket")
                if (!dir.exists()) dir.mkdirs()
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.FRANCE).format(Date())
                val outFile = File(dir, "audio_$stamp.m4a")
                val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                extractor.selectTrack(audioTrack)
                val outputTrack = muxer.addTrack(audioFormat)
                muxer.start()

                val maxSize = if (audioFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE))
                    audioFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE).coerceAtLeast(256 * 1024)
                else 1024 * 1024
                val buffer = ByteBuffer.allocate(maxSize)
                val info = android.media.MediaCodec.BufferInfo()
                while (true) {
                    buffer.clear()
                    val size = extractor.readSampleData(buffer, 0)
                    if (size < 0) break
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = extractor.sampleTime
                    info.flags = extractor.sampleFlags
                    muxer.writeSampleData(outputTrack, buffer, info)
                    extractor.advance()
                }
                muxer.stop()
                muxer.release()
                extractor.release()
                runOnUiThread {
                    status.text = "Terminé : ${outFile.name}\nEnregistré dans le dossier privé Musique/AudioPocket de l’application."
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Échec de l’extraction : ${e.localizedMessage ?: "format non pris en charge"}" }
            }
        }
    }
}
