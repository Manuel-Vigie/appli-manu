# AudioPocket — projet Android de démarrage

Application Android native en Kotlin, interface française.

## Fonctionnalités incluses
- Champ pour coller un lien web et l’ouvrir dans l’application correspondante (YouTube si le lien est YouTube).
- Sélection d’une vidéo locale.
- Extraction de la piste audio vers un conteneur M4A sans réencodage lorsque le codec source est compatible avec MP4.

## Limites importantes
- L’application ne télécharge ni n’extrait directement l’audio depuis YouTube.
- Utilisez uniquement des vidéos/fichiers que vous possédez ou dont vous avez l’autorisation de convertir, et respectez les conditions de la plateforme.
- Cette première version produit du M4A, pas du MP3. La conversion MP3 nécessiterait d’ajouter un encodeur MP3 adapté et maintenu.
- Certains codecs audio intégrés aux vidéos ne peuvent pas être muxés en MP4; ces fichiers afficheront une erreur.

## Ouvrir dans Android Studio
1. Décompressez le ZIP.
2. Ouvrez le dossier `AudioPocketAndroid` dans Android Studio.
3. Laissez Gradle synchroniser le projet.
4. Connectez un téléphone Android avec le débogage USB activé, ou lancez un émulateur.
5. Cliquez sur Run.

Configuration : Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35.
